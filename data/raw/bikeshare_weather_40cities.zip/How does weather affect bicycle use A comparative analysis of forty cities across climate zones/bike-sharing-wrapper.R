library(lubridate) # with_tz
library(mgcv) # GAM models
library(gridExtra) # printing PDF
library(data.table) # fread

#setwd("/Volumes/Ten/bs")
b <- read.csv("bs/bs-ll.csv",stringsAsFactors = F) # bike share lat long, time zones

f_utci <- read.csv("utci/f_utci.csv",stringsAsFactors=F)
rownames(f_utci) <- f_utci[,1]
f_utci <- f_utci[,-1]

f_rain <- read.csv("utci/f_rain.csv",stringsAsFactors=F)
rownames(f_rain) <- f_rain[,1]
f_rain <- f_rain[,-1]

mid <- function(y) { (head(as.numeric(y),-1)+tail(as.numeric(y),-1))/2 }

est_deg <- function(data_in,formula,deg) 
{ 
  mod <- gam(formula,family=gaussian(link="log"),data=data_in)  
  return (sum(predict(mod,newdata=cbind.data.frame(UTCI=data_in$UTCI+deg,Rain=data_in$Rain,Hour=data_in$Hour,
                                                   JulianDate=data_in$JulianDate),type="response")))
}

allmod <- function(in_data,deg)
{
  return (c(est_deg(in_data,Usage~s(UTCI)+Rain+s(Hour)+s(JulianDate),deg)))
}

turn_point <- function(city_number,data)
{
  data_wd <- data[data$Weekday==0,]
  data_we <- data[data$Weekday==1,]
  temp_seq <- seq(10,50,.1)
  cname <- b[city_number,]$City
  
  gam_wd <- gam(Usage~s(UTCI),family=gaussian(link="log"),data=data_wd)
  gam_we <- gam(Usage~s(UTCI),family=gaussian(link="log"),data=data_we)
  
  cat(gsub(" ","_",cname),temp_seq[which.max(predict(gam_wd,newdata=data.frame(UTCI=temp_seq),type="response"))],
      temp_seq[which.max(predict(gam_we,newdata=data.frame(UTCI=temp_seq),type="response"))],"\n",file="turn.txt",append=T)
}

get_data <- function(city_number,usage,start_day)
{
  ut <- as.numeric(f_utci[city_number,])
  tp <- as.numeric(f_rain[city_number,])
  ut1 <- as.POSIXlt(paste(start_day,"00:00"),tz="UTC")+(0:8759)*3600 
  ut1 <- as.POSIXlt(ut1)
  st_local <- with_tz(ut1,tz=b[city_number,]$TZ)
  
  data <- cbind.data.frame(UTCI=ut,Rain=tp*1e3,Usage=usage,
                           JulianDate=st_local$yday,Hour=st_local$hour,
                           Weekday=1*(ut1$wday %in% c(0,6)))
  data <- data[data$Usage > 0,]
  data <- na.omit(data)
  data$Rain <- c(0,mid(data$Rain))
  return (data)
}

temp_increase_sim <- function(city_number,data)
{
  cname <- b[city_number,]$City
  wd <- data[data$Weekday==0,]
  we <- data[data$Weekday==1,]
  e_wd_0 <- allmod(wd,0)
  e_wd_1 <- allmod(wd,1)
  e_wd_2 <- allmod(wd,2)
  e_we_0 <- allmod(we,0)
  e_we_1 <- allmod(we,1)
  e_we_2 <- allmod(we,2)
  m1 <- round(100*((e_wd_1/e_wd_0)-1),3)
  m2 <- round(100*((e_wd_2/e_wd_0)-1),3)
  m3 <- round(100*((e_we_1/e_we_0)-1),3)
  m4 <- round(100*((e_we_2/e_we_0)-1),3)
  m5 <- round(100*(((e_wd_1+e_we_1)/(e_wd_0+e_we_0))-1),3)
  m6 <- round(100*(((e_wd_2+e_we_2)/(e_wd_0+e_we_0))-1),3)
  
  cat(gsub(" ","_",cname),m1,m2,m3,m4,m5,m6,file="temp.txt","\n",append=T)
}

summary_write <- function(city_number,data)
{
  data_wd <- data[data$Weekday==0,]
  data_we <- data[data$Weekday==1,]
  cname <- b[city_number,]$City
  gam_wd <- gam(Usage~s(Hour)+s(JulianDate)+s(UTCI)+(Rain),family=gaussian(link="log"),data=data_wd)
  gam_we <- gam(Usage~s(Hour)+s(JulianDate)+s(UTCI)+(Rain),family=gaussian(link="log"),data=data_we)
  sum_wd <- anova(gam_wd)
  sum_we <- anova(gam_we)
  
  cat(gsub(" ","_",cname),sum_wd$r.sq,sum_we$r.sq, as.numeric(sum_wd$p.coeff[2]), as.numeric(sum_we$p.coeff[2]),
      cor(data_wd$UTCI,data_wd$Usage), cor(data_wd$Rain,data_wd$Usage),
      cor(data_we$UTCI,data_we$Usage), cor(data_we$Rain,data_we$Usage),
      as.numeric(sum_wd$pTerms.table[1,2]), as.numeric(sum_wd$s.table[,3]),
      as.numeric(sum_we$pTerms.table[1,2]), as.numeric(sum_we$s.table[,3]), 
      as.numeric(summary(na.omit(as.numeric(f_utci[city_number,])))),
      sum(na.omit(f_rain[city_number,]))*1e3,
      sum(data$Usage),
      nrow(data),
      "\n", file="summary.txt", append=T
  )
}

write_pdf <- function(city_number,data)
{
  cname <- b[city_number,]$City
  data_wd <- data[data$Weekday==0,]
  data_we <- data[data$Weekday==1,]
  
  #p_max <- floor(min(quantile(data_wd$Rain,.99),quantile(data_we$Rain,.99)))
  
  pdf(paste(gsub(" ","_",cname),"-hour-date-weekday.pdf",sep="")) 
  gam_dh <- gam(Usage~s(Hour)+s(JulianDate),family=gaussian(link="log"),data=data_wd)
  vis.gam(gam_dh,n.grid=50,color="topo",plot.type="contour",type="response",main="")
  dev.off()
  
  pdf(paste(gsub(" ","_",cname),"-rain-temp-weekday.pdf",sep="")) 
  gam_tp <- gam(Usage~Rain+s(UTCI),family=gaussian(link="log"),data=data_wd)
  vis.gam(gam_tp,n.grid=50,color="topo",plot.type="contour",type="response",main="",xlab="Precipitation (mm)")
  dev.off()
  
  pdf(paste(gsub(" ","_",cname),"-hour-date-weekend.pdf",sep="")) 
  gam_dh <- gam(Usage~s(Hour)+s(JulianDate),family=gaussian(link="log"),data=data_we)
  vis.gam(gam_dh,n.grid=50,color="topo",plot.type="contour",type="response",main="")
  dev.off()
  
  pdf(paste(gsub(" ","_",cname),"-rain-temp-weekend.pdf",sep="")) 
  gam_tp <- gam(Usage~Rain+s(UTCI),family=gaussian(link="log"),data=data_we)
  vis.gam(gam_tp,n.grid=50,color="topo",plot.type="contour",type="response",main="",xlab="Precipitation (mm)")
  dev.off()
  
  pdf(paste(gsub(" ","_",cname),"-rain-hour-weekday.pdf",sep="")) 
  gam_rh_wd <- gam(Usage~Rain+s(Hour),family=gaussian(link="log"),data=data_wd)
  #vis.gam(gam_rh_wd,n.grid=50,color="topo",plot.type="contour",type="response",main="",view=c("Hour","Rain"),ylim=c(0,p_max),ylab="Precipitation (mm)")
  vis.gam(gam_rh_wd,n.grid=50,color="topo",plot.type="contour",type="response",main="",view=c("Hour","Rain"),ylab="Precipitation (mm)")
  dev.off()
  
  pdf(paste(gsub(" ","_",cname),"-rain-hour-weekend.pdf",sep="")) 
  gam_rh_we <- gam(Usage~Rain+s(Hour),family=gaussian(link="log"),data=data_we)
  #vis.gam(gam_rh_we,n.grid=50,color="topo",plot.type="contour",type="response",main="",view=c("Hour","Rain"),ylim=c(0,p_max),ylab="Precipitation (mm)")
  vis.gam(gam_rh_we,n.grid=50,color="topo",plot.type="contour",type="response",main="",view=c("Hour","Rain"),ylab="Precipitation (mm)")
  dev.off()
}


get_vg <- function(city_number,data,fig)
{
  cname <- b[city_number,]$City
  data_wd <- data[data$Weekday==0,]
  data_we <- data[data$Weekday==1,]
  title1 <- paste(b[city_number,]$City," (",b[city_number,]$Trew,")",sep="")
  
  #p_max <- floor(min(quantile(data_wd$Rain,.99),quantile(data_we$Rain,.99)))
  
  if (fig==1)
  {
  gam_dh <- gam(Usage~s(Hour)+s(JulianDate),family=gaussian(link="log"),data=data_wd)
   vis.gam(gam_dh,n.grid=50,color="topo",plot.type="contour",type="response",main=title1,xlab="Hour",ylab="JulianDate")
  }
  if (fig==2)
  {
  gam_tp <- gam(Usage~Rain+s(UTCI),family=gaussian(link="log"),data=data_wd)
   vis.gam(gam_tp,n.grid=50,color="topo",plot.type="contour",type="response",main=title1,xlab="Precipitation (mm)",ylab="UTCI")
  }  
  if (fig==3)
  {
  gam_dh <- gam(Usage~s(Hour)+s(JulianDate),family=gaussian(link="log"),data=data_we)
   vis.gam(gam_dh,n.grid=50,color="topo",plot.type="contour",type="response",main=title1,xlab="Hour",ylab="JulianDate")
  }
  
  if (fig==4)
  {
  gam_tp <- gam(Usage~Rain+s(UTCI),family=gaussian(link="log"),data=data_we)
  vis.gam(gam_tp,n.grid=50,color="topo",plot.type="contour",type="response",main=title1,xlab="Precipitation (mm)",ylab="UTCI")
  }
  
  if (fig==5)
  {
  gam_rh_wd <- gam(Usage~Rain+s(Hour),family=gaussian(link="log"),data=data_wd)
  #vis.gam(gam_rh_wd,n.grid=50,color="topo",plot.type="contour",type="response",main="",view=c("Hour","Rain"),ylim=c(0,p_max),ylab="Precipitation (mm)")
  vis.gam(gam_rh_wd,n.grid=50,color="topo",plot.type="contour",type="response",main=title1,view=c("Hour","Rain"),ylab="Precipitation (mm)")
  }
  
  if (fig==6)
  {
  gam_rh_we <- gam(Usage~Rain+s(Hour),family=gaussian(link="log"),data=data_we)
  #vis.gam(gam_rh_we,n.grid=50,color="topo",plot.type="contour",type="response",main="",view=c("Hour","Rain"),ylim=c(0,p_max),ylab="Precipitation (mm)")
  vis.gam(gam_rh_we,n.grid=50,color="topo",plot.type="contour",type="response",main=title1,view=c("Hour","Rain"),ylab="Precipitation (mm)")
  }
  
}

get_gam_data <- function(data,fig)
{
  cname <- b[city_number,]$City
  data_wd <- data[data$Weekday==0,]
  data_we <- data[data$Weekday==1,]

  if (fig==1)
    gam_model <- gam(Usage~s(Hour)+s(JulianDate),family=gaussian(link="log"),data=data_wd)
  if (fig==2)
    gam_model <- gam(Usage~Rain+s(UTCI),family=gaussian(link="log"),data=data_wd)
  if (fig==3)
    gam_model <- gam(Usage~s(Hour)+s(JulianDate),family=gaussian(link="log"),data=data_we)
  if (fig==4)
    gam_model <- gam(Usage~Rain+s(UTCI),family=gaussian(link="log"),data=data_we)
  if (fig==5)
    gam_model <- gam(Usage~Rain+s(Hour),family=gaussian(link="log"),data=data_wd)
  if (fig==6)
    gam_model <- gam(Usage~Rain+s(Hour),family=gaussian(link="log"),data=data_we)
  gam_model
}
  
plot_fig <- function(models,city_number,fig)
{
  title1 <- paste(b[city_number,]$City," (",b[city_number,]$Trew,")",sep="")
  
  if (fig==1)
  vis.gam(models[[city_number]],n.grid=50,color="topo",plot.type="contour",type="response",main=title1,xlab="Hour",ylab="JulianDate")
  if (fig==2)
  vis.gam(models[[city_number]],n.grid=50,color="topo",plot.type="contour",type="response",main=title1,xlab="Precipitation (mm)",ylab="UTCI")
  if (fig==3)
  vis.gam(models[[city_number]],n.grid=50,color="topo",plot.type="contour",type="response",main=title1,xlab="Hour",ylab="JulianDate")
  if (fig==4)
  vis.gam(models[[city_number]],n.grid=50,color="topo",plot.type="contour",type="response",main=title1,xlab="Precipitation (mm)",ylab="UTCI")
  if (fig==5)
  vis.gam(models[[city_number]],n.grid=50,color="topo",plot.type="contour",type="response",main=title1,view=c("Hour","Rain"),ylab="Precipitation (mm)")
  if (fig==6)
  vis.gam(models[[city_number]],n.grid=50,color="topo",plot.type="contour",type="response",main=title1,view=c("Hour","Rain"),ylab="Precipitation (mm)")
}


plot_city <- function(models,city_number,fig)
{
  title1 <- paste(b[city_number,]$City," (",b[city_number,]$Trew,")",sep="")
  
  if (fig==1)
    vis.gam(models[[city_number]],n.grid=50,color="topo",plot.type="contour",
            type="response",main="Hour vs Season Weekday",xlab="Hour",ylab="JulianDate")
  if (fig==2)
    vis.gam(models[[city_number]],n.grid=50,color="topo",plot.type="contour",
            type="response",main="Precipitation vs UTCI Weekday",xlab="Precipitation (mm)",ylab="UTCI")
  if (fig==3)
    vis.gam(models[[city_number]],n.grid=50,color="topo",plot.type="contour",
            type="response",main="Hour vs Season Weekend",xlab="Hour",ylab="JulianDate")
  if (fig==4)
    vis.gam(models[[city_number]],n.grid=50,color="topo",plot.type="contour",
            type="response",main="Precipitation vs UTCI Weekend",xlab="Precipitation (mm)",ylab="UTCI")
  if (fig==5)
    vis.gam(models[[city_number]],n.grid=50,color="topo",plot.type="contour",
            type="response",main="Hour vs Precipitation Weekday",view=c("Hour","Rain"),ylab="Precipitation (mm)")
  if (fig==6)
    vis.gam(models[[city_number]],n.grid=50,color="topo",plot.type="contour",
            type="response",main="Hour vs Precipitation Weekend",view=c("Hour","Rain"),ylab="Precipitation (mm)")
}

get_data_wrapper <- function(city_number)
{
if(city_number == 1)
{
  
  #####
  ##### New York City
  #####
  
nyfile <- list.files(path="citibike",pattern="^2017.*csv")
dh_freq <- rep(0,8760) # hours of the year - 8,760 for 2017
for (file in nyfile)
{
  cat(file,"\n")
  data <- fread(file=paste("citibike",file,sep="/"), sep=",", colClasses=c("NULL", NA, rep("NULL",13)))
  st <- as.POSIXlt(as.character(unlist(data)),tz="America/New_York") 
  st1 <- with_tz(st,"UTC") 
  st1 <- st1[st1$year==117,]
  a <- st1$yday*24+round(st1$hour+st1$min/60+st1$sec/3600)+1
  a <- a[a<=8760]
  
  aa <- table(a)
  dh_freq[as.integer(names(aa))] <- as.numeric(aa)
}
data <- get_data(city_number,dh_freq,"2017-01-01")
}
  
if (city_number == 2)
{

#####
##### Minneapolis
#####

mnfile <- list.files(path="Nice_ride_data_2017_season",pattern=".*trip_history.*2017.*csv")
dh_freq <- rep(0,8760) # hours of the year
for (file in mnfile)
{
  cat(file,"\n")
  
  data <- fread(file=paste("Nice_ride_data_2017_season",file,sep="/"), sep=",", colClasses=c(NA, rep("NULL",7)))
  st <- as.POSIXlt(as.character(unlist(data)),tz="America/Chicago",format="%m/%d/%Y %H:%M") 
  st1 <- with_tz(st,"UTC")
  st1 <- st1[st1$year==117,]
  
  a <- st1$yday*24+round(st1$hour+st1$min/60+st1$sec/3600)+1
  a <- a[a<=8760]
  
  aa <- table(a)
  dh_freq[as.integer(names(aa))] <- as.numeric(aa)
}

data <- get_data(city_number,dh_freq,"2017-01-01")
}
  
if (city_number == 3)
{

#####
##### Vancouver
#####

vafile <- list.files(path=".",pattern="Mobi_System_Data_2017.csv")

dh_freq <- rep(0,8760) # hours of the year
for (file in vafile)
{
  cat(file,"\n")
  
  data <- fread(file=paste(".",file,sep="/"), sep=",", colClasses=c(NA, rep("NULL",14)))
  st <- as.POSIXlt(as.character(unlist(data)),tz="America/Vancouver",format="%d/%m/%y %H:%M") ### day month year in CA!!!! two-digit year!!
  st1 <- with_tz(st,"UTC")
  st1 <- st1[st1$year==117,]
  
  a <- st1$yday*24+round(st1$hour+st1$min/60+st1$sec/3600)+1
  a <- a[a<=8760]
  
  
  aa <- table(a)
  dh_freq[as.integer(names(aa))] <- as.numeric(aa)
}

data <- get_data(city_number,dh_freq,"2017-01-01")
}
  
if (city_number == 4)
{

#####
##### Chicago
#####


chicfile <- list.files(path=".",pattern="Divvy_Trips_2017_Q.*csv")
dh_freq <- rep(0,8760) # hours of the year
for (file in chicfile)
{
  cat(file,"\n")
  
  data <- fread(file=paste(".",file,sep="/"), sep=",", colClasses=c("NULL",NA, rep("NULL",10)))
  st <- as.POSIXlt(as.character(unlist(data)),tz="America/Chicago",format="%m/%d/%Y %H:%M") 
  st1 <- with_tz(st,"UTC") 
  st1 <- st1[st1$year==117,]
  a <- st1$yday*24+round(st1$hour+st1$min/60+st1$sec/3600)+1
  a <- a[a<=8760]
  aa <- table(a)
  dh_freq[as.integer(names(aa))] <- as.numeric(aa)
}

data <- get_data(city_number,dh_freq,"2017-01-01")
}
  
if (city_number == 5)
{

#####
##### Los Angeles
#####

la1file <- c("la_metro_gbfs_trips_Q1_2017.csv","metro-bike-share-trips-2017-q3.csv")
la2file <- c("la_metro_gbfs_trips_Q2_2017.csv","metro-bike-share-trips-2017-q4-v2.csv")

dh_freq <- rep(0,8760) # hours of the year
for (file in la2file)
{
  cat(file,"\n")
  
  data <- fread(file=paste(".",file,sep="/"), sep=",", colClasses=c("NULL","NULL",NA, rep("NULL",11)))
  st <- as.POSIXlt(as.character(unlist(data)),tz="America/Los_Angeles",format="%Y-%m-%d %H:%M:%S") 
  st1 <- with_tz(st,"UTC")
  st1 <- st1[st1$year==117,]
  
  a <- st1$yday*24+round(st1$hour+st1$min/60+st1$sec/3600)+1
  a <- a[a<=8760]
  
  aa <- table(a)
  dh_freq[as.integer(names(aa))] <- as.numeric(aa)
}

for (file in la1file)
{
  cat(file,"\n")
  
  data <- fread(file=paste(".",file,sep="/"), sep=",", colClasses=c("NULL","NULL",NA, rep("NULL",11)))
  st <- as.POSIXlt(as.character(unlist(data)),tz="America/Los_Angeles",format="%m/%d/%Y %H:%M") 
  st1 <- with_tz(st,"UTC")
  st1 <- st1[st1$year==117,]
  
  a <- st1$yday*24+round(st1$hour+st1$min/60)+1
  a <- a[a<=8760]
  
  aa <- table(a)
  dh_freq[as.integer(names(aa))] <- as.numeric(aa)
}


##### Remove hours with > 100 trips. unusual usage patterns on 2017-10-08 (Sunday), 2017-12-10 (Sunday)
##### these cannot be modelled against weather - could be special events.

data <- get_data(city_number,dh_freq,"2017-01-01")
data <- data[data$Usage > 0,]
data <- data[data$Usage <= 100,]
}

if (city_number == 6)
{
#####
##### Washington DC
#####

wa1file <- list.files(pattern="2017Q.-capitalbikeshare-tripdata.csv")

dh_freq <- rep(0,8760) # hours of the year
for (file in wa1file)
{
  cat(file,"\n")
  
  data <- fread(file=paste(".",file,sep="/"), sep=",", colClasses=c("NULL",NA, rep("NULL",7)))
  st <- as.POSIXlt(as.character(unlist(data)),tz="America/New_York",format="%Y-%m-%d %H:%M:%S") 
  st1 <- with_tz(st,"UTC")
  st1 <- st1[st1$year==117,]
  
  a <- st1$yday*24+round(st1$hour+st1$min/60+st1$sec/3600)+1
  a <- a[a<=8760]
  
  aa <- table(a)
  dh_freq[as.integer(names(aa))] <- as.numeric(aa)
}

data <- get_data(city_number,dh_freq,"2017-01-01")
}
  
if (city_number == 37)
{

#####
##### Toronto
#####

to1file <- list.files(path="toronto-2017",pattern="Bikeshare.*Q[12].*csv")
to2file <- list.files(path="toronto-2017",pattern="Bikeshare.*Q[3].*csv")
to3file <- list.files(path="toronto-2017",pattern="Bikeshare.*Q[4].*csv")

dh_freq <- rep(0,8760) # hours of the year
for (file in to1file)
{
  cat(file,"\n")
  
  data <- fread(file=paste("toronto-2017",file,sep="/"), sep=",", colClasses=c("NULL",NA, rep("NULL",7)))
  st <- as.POSIXlt(as.character(unlist(data)),tz="UTC",format="%d/%m/%Y %H:%M") 
  st1 <- with_tz(st,"UTC")
  st1 <- st1[st1$year==117,]
  
  a <- st1$yday*24+round(st1$hour+st1$min/60)+1
  a <- a[a<=8760]
  
  aa <- table(a)
  dh_freq[as.integer(names(aa))] <- as.numeric(aa)
}

for (file in to2file)
{
  cat(file,"\n")
  
  data <- fread(file=paste("toronto-2017",file,sep="/"), sep=",", colClasses=c("NULL",NA, rep("NULL",5)))
  st <- as.POSIXlt(as.character(unlist(data)),tz="America/Toronto",format="%m/%d/%Y %H:%M") 
  st1 <- with_tz(st,"UTC")
  st1 <- st1[st1$year==117,]
  
  a <- st1$yday*24+round(st1$hour+st1$min/60)+1
  a <- a[a<=8760]
  
  aa <- table(a)
  dh_freq[as.integer(names(aa))] <- as.numeric(aa)
}

for (file in to3file)
{
  cat(file,"\n")
  
  data <- fread(file=paste("toronto-2017",file,sep="/"), sep=",", colClasses=c("NULL",NA, rep("NULL",5)))
  st <- as.POSIXlt(as.character(unlist(data)),tz="America/Toronto",format="%m/%d/%y %H:%M:%S") 
  st1 <- with_tz(st,"UTC")
  st1 <- st1[st1$year==117,]
  a <- st1$yday*24+round(st1$hour+st1$min/60+st1$sec/3600)+1
  a <- a[a<=8760]
  
  aa <- table(a)
  dh_freq[as.integer(names(aa))] <- as.numeric(aa)
}

data <- get_data(city_number,dh_freq,"2017-01-01")
}
  
if (city_number %in% 38:40)
{

#####
##### Norway
#####

noci <- c("trondheim","oslo","bergen")


  no1file <- list.files(path=noci[city_number-37],pattern=".*csv")
  
  dh_freq <- rep(0,8760) # hours of the year
  for (file in no1file)
  {
    #cat(file,"\n")
    data <- fread(file=paste(noci[city_number-37],file,sep="/"), sep=",", colClasses=c(NA, rep("NULL",12)))
    #st <- as.POSIXlt(as.character(unlist(data)),tz="UTC",format="%Y-%m-%d %H:%M:%OS") # should be UTC according to format
    st <- as.POSIXlt(data$started_at,tz="UTC",format="%Y-%m-%d %H:%M:%S")
    st1 <- with_tz(st,"UTC")
    st1 <- st1[st1$year==119,]
    
    a <- st1$yday*24+round(st1$hour+st1$min/60+st1$sec/3600)+1
    a <- a[a<=8760]
    
    aa <- table(a)
    dh_freq[as.integer(names(aa))] <- as.numeric(aa)
  }
  
  data <- get_data(city_number,dh_freq,"2019-01-01")

}
  
if (city_number == 35)
{
  
#####
##### London
#####

lofile <- list.files(path="london",pattern=".*Jo.*csv")

dh_freq <- rep(0,8760) # hours of the year
for (file in lofile)
{
  cat(file,"\n")
  
  data <- fread(file=paste("london",file,sep="/"), sep=",", colClasses=c(rep("NULL",6),NA,rep("NULL",2)))
  not2017 <- grep("/201[68]",data$`Start Date`)
  if (length(not2017) > 0) data <- data[-not2017,] ## no start dates in 2018 or 2016
  st <- as.POSIXlt(as.character(unlist(data)),tz="Europe/London",format="%d/%m/%Y %H:%M")
  st1 <- with_tz(st,"UTC")
  st1 <- st1[st1$year==117,]
  
  a <- st1$yday*24+round(st1$hour+st1$min/60)+1
  a <- a[a<=8760]
  
  aa <- table(a)
  dh_freq[as.integer(names(aa))] <- as.numeric(aa)
}

data <- get_data(city_number,dh_freq,"2017-01-01")
}

if (city_number %in% c(7:34,36))
{
#####
##### Stock Schemes
#####

j <- read.csv("bs/stock-data.csv",header=F,col.names=c("city","day","hour","freq"),stringsAsFactors = F)

  cname <- tolower(unique(b[city_number,]$City))
  jsub <- j[j$city==cname,]
  jsub_day_hr <- paste(jsub$day,jsub$hour)
  st <- as.POSIXlt(as.character(jsub_day_hr),tz="UTC",format="%Y-%m-%d %H") 
  data <- get_data(city_number,jsub$freq,substr(min(st),1,13))
}
  data
}

# write figures 2-9

city_data <- lapply(1:40,get_data_wrapper)
gam_data_1 <- lapply(city_data,get_gam_data,fig=1) # 2a
gam_data_2 <- lapply(city_data,get_gam_data,fig=2) # 2e
gam_data_3 <- lapply(city_data,get_gam_data,fig=3) # 2b
gam_data_4 <- lapply(city_data,get_gam_data,fig=4) # 2f
gam_data_5 <- lapply(city_data,get_gam_data,fig=5) # 2c
gam_data_6 <- lapply(city_data,get_gam_data,fig=6) # 2d

# fig 2a - by season and hour, weekdays

# fig 2b - by season and hour, weekends

# fig 2c - by precipitation and hour, weekdays

# fig 2d - by precipitation and hour, weekends

# fig 2e - by UTCI and precipitation, weekdays

# fig 2f - by UTCI and precipitation, weekends

cex_axis <- 1 # axis annotation
cex_lab <- 1 # x and y labels
cex_main <- 1 # main title
cex_sub <- 1 # sub-titles
page_width <- 8.27 
page_height <- 11.69 
page_mar <- c(2,2,2,2)

pdf("fig_2a.pdf", width=page_width, height=page_height)
par(mfrow=c(8,5),mar=page_mar,cex.main=cex_main,cex.lab=cex_lab) # width, height, mar, cex params adjustable
for (n in 1:40)
plot_fig(gam_data_1,n,1)
dev.off()

pdf("fig_2e.pdf", width=page_width, height=page_height)
par(mfrow=c(8,5),mar=page_mar,cex.main=cex_main,cex.lab=cex_lab) # width, height, mar, cex params adjustable
for (n in 1:40)
  plot_fig(gam_data_2,n,2)
dev.off()

pdf("fig_2b.pdf", width=page_width, height=page_height)
par(mfrow=c(8,5),mar=page_mar,cex.main=cex_main,cex.lab=cex_lab) # width, height, mar, cex params adjustable
for (n in 1:40)
  plot_fig(gam_data_3,n,3)
dev.off()

pdf("fig_2f.pdf", width=page_width, height=page_height)
par(mfrow=c(8,5),mar=page_mar,cex.main=cex_main,cex.lab=cex_lab) # width, height, mar, cex params adjustable
for (n in 1:40)
  plot_fig(gam_data_4,n,4)
dev.off()

pdf("fig_2c.pdf", width=page_width, height=page_height)
par(mfrow=c(8,5),mar=page_mar,cex.main=cex_main,cex.lab=cex_lab) # width, height, mar, cex params adjustable
for (n in 1:40)
  plot_fig(gam_data_5,n,5)
dev.off()

pdf("fig_2d.pdf", width=page_width, height=page_height)
par(mfrow=c(8,5),mar=page_mar,cex.main=cex_main,cex.lab=cex_lab) # width, height, mar, cex params adjustable
for (n in 1:40)
  plot_fig(gam_data_6,n,6)
dev.off()

# fig 3 - NYC, 3 cols, 2 rows; cols = season by hour, precip by hour, UTCI and precip; rows = wend / wday
pdf("fig_3.pdf", width=page_width, height=page_height)
par(mfrow=c(3,2),mar=page_mar,cex.main=cex_main,cex.lab=cex_lab) # width, height, mar, cex params adjustable
plot_city(gam_data_1,1,1)
plot_city(gam_data_3,1,3)
plot_city(gam_data_5,1,5)
plot_city(gam_data_6,1,6)
plot_city(gam_data_2,1,2)
plot_city(gam_data_4,1,4)
dev.off()

# fig 4 - Seville, 3 cols, 2 rows; cols = season by hour, precip by hour, UTCI and precip; rows = wend / wday
pdf("fig_4.pdf", width=page_width, height=page_height)
par(mfrow=c(3,2),mar=page_mar,cex.main=cex_main,cex.lab=cex_lab) # width, height, mar, cex params adjustable
plot_city(gam_data_1,29,1)
plot_city(gam_data_3,29,3)
plot_city(gam_data_5,29,5)
plot_city(gam_data_6,29,6)
plot_city(gam_data_2,29,2)
plot_city(gam_data_4,29,4)
dev.off()
# fig 5 - Valencia, 3 cols, 2 rows; cols = season by hour, precip by hour, UTCI and precip; rows = wend / wday
pdf("fig_5.pdf", width=page_width, height=page_height)
par(mfrow=c(3,2),mar=page_mar,cex.main=cex_main,cex.lab=cex_lab) # width, height, mar, cex params adjustable
plot_city(gam_data_1,8,1)
plot_city(gam_data_3,8,3)
plot_city(gam_data_5,8,5)
plot_city(gam_data_6,8,6)
plot_city(gam_data_2,8,2)
plot_city(gam_data_4,8,4)
dev.off()
# fig 6 - Paris, 3 cols, 2 rows; cols = season by hour, precip by hour, UTCI and precip; rows = wend / wday
pdf("fig_6.pdf", width=page_width, height=page_height)
par(mfrow=c(3,2),mar=page_mar,cex.main=cex_main,cex.lab=cex_lab) # width, height, mar, cex params adjustable
plot_city(gam_data_1,7,1)
plot_city(gam_data_3,7,3)
plot_city(gam_data_5,7,5)
plot_city(gam_data_6,7,6)
plot_city(gam_data_2,7,2)
plot_city(gam_data_4,7,4)
dev.off()
# fig 7 - Brisbane, 3 cols, 2 rows; cols = season by hour, precip by hour, UTCI and precip; rows = wend / wday
pdf("fig_7.pdf", width=page_width, height=page_height)
par(mfrow=c(3,2),mar=page_mar,cex.main=cex_main,cex.lab=cex_lab) # width, height, mar, cex params adjustable
plot_city(gam_data_1,9,1)
plot_city(gam_data_3,9,3)
plot_city(gam_data_5,9,5)
plot_city(gam_data_6,9,6)
plot_city(gam_data_2,9,2)
plot_city(gam_data_4,9,4)
dev.off()
# fig 8 - Kaohsiung, 3 cols, 2 rows; cols = season by hour, precip by hour, UTCI and precip; rows = wend / wday
pdf("fig_8.pdf", width=page_width, height=page_height)
par(mfrow=c(3,2),mar=page_mar,cex.main=cex_main,cex.lab=cex_lab) # width, height, mar, cex params adjustable
plot_city(gam_data_1,36,1)
plot_city(gam_data_3,36,3)
plot_city(gam_data_5,36,5)
plot_city(gam_data_6,36,6)
plot_city(gam_data_2,36,2)
plot_city(gam_data_4,36,4)
dev.off()

# fig 9 - Trondheim, 3 cols, 2 rows; cols = season by hour, precip by hour, UTCI and precip; rows = wend / wday
pdf("fig_9.pdf", width=page_width, height=page_height)
par(mfrow=c(3,2),mar=page_mar,cex.main=cex_main,cex.lab=cex_lab) # width, height, mar, cex params adjustable
# plot_city(gam_data_1,38,1)
# plot_city(gam_data_5,38,5)
# plot_city(gam_data_2,38,2)
# plot_city(gam_data_3,38,3)
# plot_city(gam_data_6,38,6)
# plot_city(gam_data_4,38,4)

# old - 1, 5, 2, 3, 6, 4 -- new -- 1, 3, 5, 6, 2, 4

plot_city(gam_data_1,38,1)
plot_city(gam_data_3,38,3)
plot_city(gam_data_5,38,5)
plot_city(gam_data_6,38,6)
plot_city(gam_data_2,38,2)
plot_city(gam_data_4,38,4)
dev.off()

# write other data, and single PDF files if needed

temp_increase_sim(city_number,data)
summary_write(city_number,data)
#write_pdf(city_number,data)
turn_point(city_number,data)
